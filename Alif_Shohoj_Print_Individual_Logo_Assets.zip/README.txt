Alif Shohoj Printby AAA Tech Solutions — Logo Asset Pack
Palette: Black + Gold | Concept: Modern Print & Digital

Files:
01_primary_logo_black_gold.svg — scalable primary logo artwork (SVG source)
01_primary_logo_transparent.png — transparent PNG logo
02_primary_logo_white_background.jpg — JPG logo on white background
03_app_icon_black_gold.svg — scalable app icon source
03_app_icon_512.png — 512×512 app icon PNG
04_favicon_64.png — 64×64 favicon PNG
05_app_icon_black_background.jpg — app icon JPG
06_animated_logo_preview.gif — actual animated GIF (looping glow/orbit effect)

Brand name:
Alif Shohoj Printby AAA Tech Solutions

Notes:
- SVG files can be opened in Inkscape, Illustrator, Figma, or a browser.
- PNG is suitable for transparent-background use.
- JPG does not support transparency.
- GIF is a simple looping animation, not a video.
- Review the visual spelling and typography before commercial/official deployment.
